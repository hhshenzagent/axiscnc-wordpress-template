=== Translate Wordpress with GTranslate ===
Contributors: edo888
Author: Translate AI Multilingual Solutions
Tags: translate, translator, multilingual, translation, language
Requires at least: 6.0.1
Tested up to: 7.1
Stable tag: 5.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://gtranslate.io/?xyz=998#pricing
Author URI: https://gtranslate.io/?xyz=998

Translate WordPress with Google Translate multilanguage plugin using AI translation. Complete multilingual SEO solution, WooCommerce compatible.

== Description ==

Translate WordPress with GTranslate plugin uses Google Translate **AI translation** service to **translate wordpress** site with Google power and make it **multilingual**. With 103 available languages your site will be available to more than 99% of internet users. Our paid versions are **fully SEO compatible** which will **increase your international traffic and sales**. This translate plugin is a budget multilingual WordPress solution which combines automatic and human translations to save money and is easy to implement.

GTranslate is a leading website translation services provider since 2008, it moves away the language barriers.

Compared to other translation plugins for WordPress, we use cloud based approach which does not slow down your website. In addition to that, we can offer complete SEO features based on sub-domains with our paid options, which can make your website appear in search engines in different languages which will increase your international traffic and sales. In our paid versions we DO NOT limit the number of words or the number of translated pageviews. You DO NOT pay additionally for automatic translations.

Please use [GTranslate Support](https://wordpress.org/support/plugin/gtranslate) for your questions and support requests! We are multilingual!

Please check our [FAQ](https://gtranslate.io/?xyz=998#faq) to get quick answers.

**Free translation service: permitted use**

Under the [GTranslate Terms of Service](https://gtranslate.io/terms), the free translation service is available for personal, educational, internal testing, nonprofit and governmental purposes, provided the use does not directly generate revenue from the service. Nonprofit use must further nonprofit activities; governmental use includes public institutions and other public-sector entities. Commercial or revenue-generating use requires an applicable paid subscription. This free-service restriction does not apply to free trials of paid subscriptions.

These service conditions do not change the WordPress plugin code's GPLv2-or-later license.

**Features**

* Automatic machine translation
* Translate website on the fly
* Translate posts and pages
* Translate categories and tags
* Menus and widgets translation
* Themes and plugins translation
* Right to left language support
* Google Translate website translator widget alternative
* Auto-switch language based on browser defined language
* Available styles Float, Dropdown, Flags, Flags with dropdown, Nice dropdown with flags, Flags with language names, Flags with language codes, Language names, Language codes, Globe, Popup
* Floating language selector
* WooCommerce shop translation
* Multilingual language names in native alphabet
* Alternative flags for Quebec, Canada, USA, Brazil, Mexico, Argentina, Colombia
* Lazy loading for language flags and js libraries to boost performance
* Lightweight vanilla javascript without dependencies
* Forum Support

**Paid Features**

* Multilingual SEO - Enable search engine indexing
* Neural machine translations with human level translation quality
* Increase traffic and AdSense revenue
* Search engine friendly (SEF) URLs
* Yoast SEO compatible - translate meta keywords, meta description, schema.org data structures, translate sitemaps
* WooCommerce compatible - translate products, schema.org data structures
* You can have sub-directory (example.com/**es**/) or sub-domain (**es.**example.com) URL structure
* URL Translation aka slug translation is possible (example.com/about-us &rarr; example.es/sobre-nosotros)
* Add hreflang tags for translated alternatives
* You can manually correct translations
* In context translation interface (make corrections without losing the context)
* Meta data translation (meta keywords, meta description)
* Translating schema.org microdata for better search engine appearance
* Seamless updates (cloud service updated on our side - SaaS, you do not need to worry about backups on your side)
* JSON format translation
* Translate WooCommerce emails
* AMP translation (Accelerated Mobile Pages translation)
* Image localization - Media translation
* Translation Proxy (aka Translation Delivery Network)
* Centralized Translation Cache - We revise and improve translations over time
* Language Hosting (**example.fr**)
* User Dashboard with Analytics
* Live Chat Support

**See also**

If you are looking for unlimited, high-quality automatic translations, check out [TranslateX](https://translatex.com) - an automatic translation API offering unlimited translation for your website or application.

We also offer integration plugins:
**[TranslateX for Loco Translate](https://wordpress.org/plugins/translatex-for-loco-translate/)** - integrate TranslateX API directly into Loco Translate for seamless, unlimited automatic translations.
**[TranslateX for TranslatePress](https://wordpress.org/plugins/translatex-for-translatepress/)** - bring unlimited automatic translation to TranslatePress using TranslateX API.

These solutions make it easy to supercharge your WordPress multilingual setup with TranslateX's secure and affordable API.

**GTranslate Wordpress Demo**
[youtube https://www.youtube.com/watch?v=9mtC3LFBErY]

**Watch GTranslate Tour**
[youtube https://www.youtube.com/watch?v=R4mfiKGZh_g]

**Edit Translations Demo (paid)**
[youtube https://www.youtube.com/watch?v=YwSy3VtQx3I]

== External services ==
This plugin uses external services to load the language selector and obtain automatic translations.

**GTranslate widget delivery**

When the widget loads, the visitor's browser requests its files from `cdn.gtranslate.net` over HTTPS. GTranslate, Inc. provides the widget, which connects the visitor's browser to the translation service.

**Google translation requests**

When page translation is requested, the widget sends page text for translation from the visitor's browser to `translate-pa.googleapis.com` over HTTPS. Google processes these translation requests. The content sent is the page text being translated.

Loading widget files and requesting translations are separate network operations. These requests also expose standard connection and HTTP request information, such as the visitor's IP address and browser headers, to the receiving service. Provider processing and retention practices are described in the applicable policies; browser-based translation does not mean that no data leaves the browser or that providers retain no data.

If you configure a paid translation proxy service, translated versions of your website are processed and served through GTranslate's cloud infrastructure according to your service configuration.

* GTranslate, Inc.: [Terms of Service](https://gtranslate.io/terms), [Privacy Policy](https://gtranslate.io/privacy-policy)
* Google: [Terms of Service](https://policies.google.com/terms), [Privacy Policy](https://policies.google.com/privacy)

Review these services when updating your website's privacy information and configuring any consent or content-security controls. The plugin requires access to the relevant external services for translation to work.


== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/gtranslate` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings &rarr; GTranslate screen to configure the plugin
1. There are 6 ways you can place the language selector on your website

**1. Floating Language Selector**
You can turn on Floating language selector option from Settings &rarr; GTranslate screen and it will show the language selector in appropriate location (Top Right, Bottom Right, Top Left or Bottom Left).

**2. Showing in Menu**
You can select from the list of available menus in which menu the language selector should appear.

**3. Shortcode in Menu**
You can create a new Custom Link menu item with URL = #, Link Text = English and add the following shortcode in the Description: `[gt-link lang="en" label="English" widget_look="flags_name"]`
Where widget_look can be one of the following: `flags`, `flags_code`, `flags_name`, `lang_codes`, `lang_names`
Make sure to enable "Description" under "Show advanced menu properties" in "Screen Options" dropdown on top of the screen.

**4. Use GTranslate shortcode**
You can use `[gtranslate]` shortcode anywhere on your website including posts, pages, text widgets.
You can edit your template files and use `<?php echo do_shortcode('[gtranslate]'); ?>` in HTML which will render the language selector.

**5. Use GTranslate Widget**
You can use Appearence &rarr; Widgets screen to publish GTranslate widget inside a sidebar of your template.

**6. Wrapper CSS Selector**
You can use a CSS selector and the language selector will appear inside the matching elements.

If you have any issues, please do not hesitate to use our [Support Forum](https://wordpress.org/support/plugin/gtranslate) for free version or [Live Chat](https://gtranslate.io/?xyz=998#contact) for paid version.

== Frequently Asked Questions ==

= It doesn't translate, what to do? =
Please check [GTranslate Support Forum](https://wordpress.org/support/plugin/gtranslate) and feel free to create a new topic if you cannot find answers.

= What is GTranslate? =
GTranslate can translate your website into multiple languages and make it multilingual.

* Multilingual solution makes your website available to the world
* One click translation helps visitors to read your site in their native language
* Free automatic translation translates your site instantly upon installation
* Professional translation by a human being is available
* Customizable language switcher lets you choose the suitable layout for your site
* Analytics provides insight into your audience and user activity

[vimeo http://vimeo.com/30132555]

= Why has the translation widget changed? =
Version 5.0.1 replaces the legacy Google Website Translator widget with the GTranslate widget following Google's announcement that support for its old widget ends on October 1, 2026. You can continue managing this plugin under Settings > GTranslate.

Read more [Google Translate Website Widget Is Shutting Down: What to Use Instead](https://gtranslate.io/blog/google-translate-website-widget-discontinued)

= Is it FREE? =
Yes! Use of the free translation service is subject to the permitted-use conditions in the Description. [Paid subscriptions](https://gtranslate.io/#pricing) provide additional service features.

= What is the quality of translation? =
In our free version we use Phrase Based Machine Translations provided by Google Translate, while in our paid versions use Google Translate Neural Translations which are very accurate for popular language pairs.
In the paid versions you can refine the automatic translations yourself or order professional translations or proofreading of a translated content.
You can get a translation cost estimate by using our [Website Translation Cost Calculator](https://gtranslate.io/website-translation-quote)

= Are the translations provided free of charge? =
Eligible use is covered by the free service described above. Otherwise, translation is provided under the applicable subscription. Review the service conditions and current plan details before choosing a service for your website.

= Can I use it on a commercial website or WooCommerce store? =
Commercial or revenue-generating use of the GTranslate service requires an applicable paid subscription. Technical compatibility with WooCommerce does not remove this requirement.

= Do existing websites need to review the service conditions? =
Yes. Review the replacement service's terms before updating your live website. If you need clarification about your existing installation or subscription, contact [GTranslate support](https://gtranslate.io/#contact).

= Can I modify the translations? =
That feature is available only in our paid version. You will be able to make edits directly on the page without losing the context.

By the way, we can help you to translate your website with a cost effective approach by post-editing your automatic translated content.
The proofreading service will be done by a native speakers and if you want to take the quality to another service, we also have a professional website translation service available.
You can get an instant website translation estimate by using our [Website Word Counter](https://gtranslate.io/website-translation-quote) tool.

= Which languages are supported? =
Here is the list: Afrikaans, Albanian, Amharic, Arabic, Armenian, Azerbaijani, Basque, Belarusian, Bengali, Bosnian, Bulgarian, Catalan, Cebuano, Chichewa, Chinese (Simplified), Chinese (Traditional), Corsican, Croatian, Czech, Danish, Dutch, English, Esperanto, Estonian, Filipino, Finnish, French, Frisian, Galician, Georgian, German, Greek, Gujarati, Haitian Creole, Hausa, Hawaiian, Hebrew, Hindi, Hmong, Hungarian, Icelandic, Igbo, Indonesian, Irish, Italian, Japanese, Javanese, Kannada, Kazakh, Khmer, Korean, Kurdish (Kurmanji), Kyrgyz, Lao, Latin, Latvian, Lithuanian, Luxembourgish, Macedonian, Malagasy, Malay, Malayalam, Maltese, Maori, Marathi, Mongolian, Myanmar (Burmese), Nepali, Norwegian, Pashto, Persian, Polish, Portuguese, Punjabi, Romanian, Russian, Samoan, Scottish Gaelic, Serbian, Sesotho, Shona, Sindhi, Sinhala, Slovak, Slovenian, Somali, Spanish, Sundanese, Swahili, Swedish, Tajik, Tamil, Telugu, Thai, Turkish, Ukrainian, Urdu, Uzbek, Vietnamese, Welsh, Xhosa, Yiddish, Yoruba, Zulu

= Is GTranslate SEO compatible? =
Our free version doesn't give any SEO advantage.

For SEO features and multilingual SEO you need to go with a paid version which have all the SEO advantages. Our paid version will translate your website and allow search engines to discover and index the translated content.
Unlike other translate plugins, we provide you all the possible tools to match with your multilingual SEO strategy.
For example you can have your translated content available via sub-directories (https://example.com/es, https://example.com/fr) or sub-domains (https://it.example.com, https://fr.example.com) or even you can host the translated versions on a top level country specific domain or any other domain like (https://example.fr, https://example.de), which will increase your chances to rank higher in local search engine's results pages.

= What is multilingual SEO? =
Multilingual SEO is a SEO strategy which uses new content generation technique by translating your original content and making your website multilingual. When you translate your website into many languages you actually create many new multilingual keywords targeted for international market. It helps to increase your search appearnce or impressions count on search engines results pages (SERPs), which can generate more traffic, increase sales and rise the conversion rate, because when the wording is in the correct language it is more effective.

= Is URL Translation available? =
In our paid versions we have a feature to translate URL of your website which will give you more SEO advantage.
For example http://example.com/*about-us* &rarr; http://example.com/*sobre-nosotros*

This is an important part of multilingual SEO strategy. When you have URL Translate option and translate also your website URLs also known us slugs, you are creating more keywords, which count as an improvement in your page rank for that keywords.

= Does it translate emails too? =
Yes, with our paid version we can also translate WooCommerce emails.

= How the free version differs from the paid versions? =
Free vesion is a nice looking language selector you can place on your website. It has a built in Javascript engine which allows to translate your website automatically to multiple languages. With our free translate plugin your website URL doesn't change and the translations are not stored. While paid versions are a translation proxy also known as Translation Delivery Network. We host the translated versions of your website on our cloud network under a language specific domain. In that case every language will have a separate domain or separate URL and be indexed in search engines, which will help you to increase international traffic and sales.

= What is a Translation Delivery Network? =
Translation Delivery Network is a translation proxy which mirrors your website in different languages.

GTranslate TDN technology is a cloud-based approach to the website translation task. There is no need to alter your environment and install software to localize your website. You can have your multilingual website up and running in less than 5 minutes.

We will translate your content and host your translations in our cloud network. All the visits to your translated versions will be proxied through our network to your original website, so you will have a translated mirror of your website.

This keeps away the need to use additional resources on your server like storage to store translations, compute time to render the translated pages or network bandwidth to deliver the translated pages to your website visitors. All is done through our network.

= Can I exclude some parts from being translated? =
Yes, you need to wrap the text you don't want to be translated with &lt;span class=&quot;notranslate&quot;&gt;&lt;/span&gt;.
With our paid versions you will have more control on the content which you do not want to translate. We have Skip Phrases, Skip Translations by CSS selectors and also Skip Pages features available.
You can read more about skipping translations on [How to skip translations?](https://docs.gtranslate.io/en/articles/1349930-how-to-skip-translations)

= Which plugins can it translate? =
All plugins are supported including popular plugins like WooCommerce, Yoast SEO.

Our technology allows us to translate what is visible on the page, since we are parsing the end result when your website is already generated and it doesn't matter how the content is generated and by which plugin. We can translate all HTML websites.
If you notice that something is not translated, please contact our live chat and we will be happy to solve any issues. Usually the not translated content is being loaded on your website from 3rd party sources.

We also offer you to change the images and media content on the translated versions and by doing that you can also translate the texts inside images and videos.

[vimeo http://vimeo.com/38686858]

= How Translation Delivery Network works? =
You just need to change your DNS records to add sub-domains or domains dedicated to your languages to our Translation Delivery Network.

So when someone visits the new added sub-domain we will show the translated clone of your website.

After that you can just configure and place the GTranslate Free widget on your site to enable language selection.

= What are the server requirements? =
There are no server requirements! Your website can be written in any programming language and hosted on any web server.

= What about updates? =
Updates are done seamlessly. Since the translations are hosted on our server we take care about updates. You just use up to date service every day. No need to worry about backups.

= Do I need to pay for Google Translate API key usage? =
No, we provide the automatic translations for free.

In our free version, we provide Phrase Based machine translations from Google Translate. In our paid versions, you get state-of-the-art Neural Translations. We also do not limit the number of words or translated pageviews on your website, unlike other translate plugins.

Unlike other plugins such as TranslatePress or Weglot, you do not pay additionally for automatic translations.

We also offer a cost-effective approach for improving website translations: you can request an automatic translation post-editing service (done by a native speaker), or order a professional translation. Get an instant estimate for your website at our [Website Translation Quote](https://gtranslate.io/website-translation-quote).

If you need unlimited, fast, and affordable automatic translation, check out [TranslateX](https://translatex.com) - our automatic translation API that offers unlimited translation for your website or app. We also provide integration plugins for [Loco Translate](https://wordpress.org/plugins/translatex-for-loco-translate/) and [TranslatePress](https://wordpress.org/plugins/translatex-for-translatepress/) to easily bring TranslateX's unlimited API into other popular translation plugins.

= Can I test before making a payment? =
Yes, we have a 15 days free trial for our new customers.

= How does the 15 day free trial work for your paid version? =
Trial is available for new customers only. If you do not wish to continue you may cancel any time during the trial period and you will not be charged anything.

= How can I be sure that search engines will index my website translations? =
You can check that this website is indexed in Google by searching for site:gtranslate.io.

= How I can edit the translations or order professional human translations? =
You need to go to the language you want to edit, for instance, French: http://domain.com/fr/ and add ?language_edit=1 to the end of the URL: http://domain.com/fr/?language_edit=1 and you will see the Edit buttons near each text. Read more at [How to edit translations?](https://docs.gtranslate.io/en/articles/1348921-how-to-edit-translations)

If you want us to translate your website professionally or provide you a proofreading service for automatic translated content, you can get an instant estimate from [Website Translation Quote](https://gtranslate.io/website-translation-quote), where you will get a detailed document with the list of pages, unique word count and prices to translate them.

== Screenshots ==
1. Float
2. Nice dropdown with flags (closed)
3. Nice dropdown with flags (open)
4. Globe with language flags
5. Flags with language names
6. Flags with language codes
7. Settings page
8. User Dashboard (paid)

== Changelog ==
= 5.0.1 =
* Replace the legacy Google Website Translator widget with the GTranslate website translation widget
* Document the replacement widget's external services and free-service permitted-use conditions
* Fixed a security issue involving unintended shortcode execution in email translation when the "Translate emails" option is enabled; credit to Jakub Herman

= 3.1.2 =
* Fixed deprecated warning in PHP 8 for paid version users
* Added aria-label accessibility attribute for Flags with language code and Language codes widget looks

= 3.1.1 =
* Added Gutenberg block support
* Fixed keyboard navigation issue in language selectors
* Improved paid version support for form submissions with file uploads on translated pages

= 3.0.10 =
* New widget look: Popup with search

= 3.0.9 =
* Updated localization strings on the GTranslate plugin settings page.
* Added information about TranslateX - unlimited automatic translation API, and integration plugins for Loco Translate and TranslatePress.

= 3.0.8 =
* Fixed current URL for hreflang tags when WordPress is installed in a sub-folder
* Changed sessionStorage to localStorage for more persistence when auto switching language
* Added a check for gtranslateSettings variable which can be undefined due to some cache plugins

= 3.0.7 =
* Added "gtranslate" into LiteSpeed cache delayed exclude list

= 3.0.6 =
* Added email translation support for emails sent by WP SMTP MAIL plugin
* Added "gtranslate" into LiteSpeed cache exclude list
* Fix for WooCommerce geoIP detection on WP Engine platform

= 3.0.5 =
* Fix for fatal error in email translation when args parameter is malformed
* Updated flags location to avoid additional 301 redirect for sub-domain URL structure
* Added skip translate for language links rendered by gt-link shortcode

= 3.0.4 =
* Added protection against XSS by bad acting admins
* Added flag size option for Globe widget look

= 3.0.3 =
* Fix mobile touch-no-click issue for float look in horizontal open direction mode
* Fix for invalid input in Custom CSS section which can break the settings interface
* Removed translated text highlight on hover
* Added more litespeed cache related excludes

= 3.0.2 =
* Fix for multiple appearance of the language selector in menus for some themes which call the render menu more than once
* Removed unused CSS code and additional query string

= 3.0.1 =
* Ground up rebuild with breaking changes to the language switcher
* Performance upgrades: all unnecessary assets are being lazy loaded, lightweight vanilla js without dependencies
* New CDN option for assets available
* New widget look: Float
* Popup widget look optimized and out of beta
* Dropdown widget look optimized, Select Language label customization option added
* Globe widget look optimized, globe size and color configuration options added
* Easy positioning into website menu
* Tested with the following caching plugins: Autoptimize, LiteSpeed Cache, W3 Total Cache, WP Fastest Cache, WP Rocket, WP Super Cache, WP Optimize, SG Optimizer

= 2.9.15 =
* Google Translate Toolbar CSS updated
* Added main language validity check for config.php file before modifying it

= 2.9.14 =
* Fix for images not appearing in WooCommerce PDF Invoices after translation
* Converted get parameters encoding from rfc1738 to rfc3986
* Replaced gzdecode with zlib_decode to be zlib encoding type independent

= 2.9.13 =
* Added translation support for PDF invoices in WooCommerce PDF Invoices plugin
* Fixed email translation issue with custom domains
* Fixed typo in Sundanese language name

= 2.9.12 =
* Fix for conflict with WP Rocket plugin when "Load JavaScript deferred" option is enabled

= 2.9.11 =
* Fix for Divi when both "Defer jQuery" and "Enqueue jQuery Compatibility Script" are enabled in Divi Theme Performance options

= 2.9.10 =
* Added support for deffered jQuery library loading, this should fix issues with Divi theme jQuery library defer option

= 2.9.9 =
* Fixed information disclosure security issue through url_addon/debug.txt
* Added admin notification when translation debug mode is on
* Fixed typo in Irish language name in native alphabet
* Added is_readable check for config.php file before modifying it
* Added conflict notice for WPML Multilingual CMS plugin

= 2.9.8 =
* Fix for email translation issue related to new base64 encoding format introduced in v2.9.7
* Added new fields into woocommerce script data for translation
* Removed script_loader_tag format modification, which is not necessary any more

= 2.9.7 =
* Happy New Year! :)
* Fixed language selector issue when using custom domains for different languages
* Email translation logic updated to use base64 encoding to avoid potential firewall blocks

= 2.9.6 =
* New flat flags style in SVG format
* Added check version to avoid double Google Translate library inclusion which may cause javascript "Uncaught RangeError" error in free version

= 2.9.5 =
* Fix for javascript error introduced in 2.9.4

= 2.9.4 =
* New interface for paid plans to easily configure custom domains for languages
* Adding Vary: Accept-Language response header when auto redirecting to browser language
* Google Analytics event tracking is on by default when analytics.js is present on the website, old ga.js support is removed

= 2.9.3 =
* Avoid minification of Google Translate javascript library by LiteSpeed Cache and WP Rocket cache plugins in the free version

= 2.9.2 =
* Smoother scrolling for Nice dropdown with flags language selector widget look

= 2.9.1 =
* New server added into our Translation Delivery Network

= 2.8.65 =
* Possible Cross-site scripting (XSS) vulnerability fixed, only possible for sub-domain, sub-directory paid options:
An attacker can generate a malicious link and if followed by a victim with an old browser without proper URL encoding support (<= IE 9) then javascript code can be executed on victim's computer.
Kudos to Ram Gall @ Wordfence for notifying

= 2.8.64 =
* New server added into our Translation Delivery Network

= 2.8.63 =
* Minor change: prefer IPv4 in paid version server communication as some hosts have issues with IPv6

= 2.8.62 =
* Tested with new WordPress 5.7 version
* Fix for email translation debug
* Avoid PHP warning suppression code
* Autoswitch to browser language issue related to Chinese language code is fixed
* Auto redirect to browser language issue related to Hebrew language code (he, iw) fixed

= 2.8.61 =
* Tested with new WordPress 5.6 version
* Ground up rebuild of our Translation Proxy cloud network for paid customers, now page translations are 3x faster on average.
    - New proprietary spec-compliant HTML parser which is 8x faster than PHP SimpleHTMLDom library used by TranslatePress Multilingual and Weglot Translate plugins
    - In case of invalid HTML, it will be fixed after page translation
    - New caching layer to cache translated pages, previously only original pages were cached
    - Optimized caching with option to clear all original and translated page caches
    - Better error reporting
    - New top of the line hardware with Intel Xeon multi-core processors with up to 5 Ghz clock speed

= 2.8.60 =
* Added debug option for WooCommerce Email translation

= 2.8.59 =
* Fix for redirect loop in sub-directory translate mode caused by empty get parameters: ?a=&b= -> ?a&b

= 2.8.58 =
* New monochrome flags option
* Avoids using /RegEx/ in JavaScript to not cause conflicts with WP Rocket optimizer

= 2.8.57 =
* New control options for flag size and colors of the "Nice dropdown with flags" language switcher
* Removed old PNG images for dropdown arrow and gradient background, now using SVG and CSS instead

= 2.8.56 =
* Translate WooCommerce Emails feature is fixed and is out of beta

= 2.8.55 =
* Fixed blank settings page issue when settings data is in corrupted state in database

= 2.8.54 =
* Added more servers into the list of our growing Translation Delivery Network

= 2.8.53 =
* Fixed issue in Translate Woocommerce emails feature related to wordpress magic quotes

= 2.8.52 =
* Cross-site scripting (XSS) vulnerability fixed: Only possible for sub-domain, sub-directory paid options with hreflang tags enabled:
An attacker can generate a malicious link and if followed by a victim then javascript code can be executed on victim's computer

= 2.8.51 =
* Translate WooCommerce Emails feature added, now we are in beta testing stage.
* Minor issue solved related to http request headers in Sub-directory URL structure
* FAQ updated

= 2.8.50 =
* Solved issue with wp_get_referer checks not passing on translated sub-domains
* Solved issue with http Refresh header which was not redirecting to correct URL in translated version
* Email translation is coming: we need volunteers to test translation of emails, please contact live chat

= 2.8.49 =
* Added translate support for MyHome IDX Broker plugin

= 2.8.48 =
* Fix for Javanese language hreflang code: jv instead of jw
* Typo in variable name fixed

= 2.8.47 =
* Fix for hebrew hreflang code when hebrew is the original language
* Visitor real IP detection fixed for woocommerce plugin
* Show warning when PHP Curl library is missing
* Fix {lang}.www.test.com case when auto-redirecting to browser language

= 2.8.46 =
* Fix for relative path issue for some hosts

= 2.8.45 =
* Fix for expired cacert.pem file, please update

= 2.8.44 =
* Added cacert file to verify peer when calling home
* Passing real visitor IP address when loading translations
* Logos updated

= 2.8.43 =
* New features in User Dashboard:
* Find and Replace before and after translation
* Skip Translation of Phrases
* Skip Translation by CSS selector
* Skip Translation by page URL
* Define HTML Blocks to edit translation as a whole
* Define JSON object keys which should be translated
* Optimized translation of URL slugs
* Fix for Sundanese flag
* Fix for double language code when redirection happens based on referrer

= 2.8.42 =
* New dashboard for paid customers https://my.gtranslate.io/
* Minor changes

= 2.8.41 =
* Added support for WP REST API JSON translation for posts and categories
* Deeper integration with WooCommerce
* Integration with WooCommerce Multi-Step Checkout plugin
* Integration with Agile Store Locator plugin
* Auto switch language based on browser language settigns for paid version added

= 2.8.40 =
* Updated Hebrew language code for hreflang (he instead of iw)
* Added translation for ajax_url javascript variables, previously only wp_ajax_url were translated
* Multisite support added for hreflang tags
* Fix woocommerce cart cookie path when wp in installed in folder
* Fix for incorrect http response headers regex

= 2.8.39 =
* 2 more translation proxy servers added: ani, evn

= 2.8.38 =
* Hreflang tags bug fixed
* Pricing info updated

= 2.8.37 =
* Fix for identical hreflang tags when using www prefix for domain

= 2.8.36 =
* Option to add hreflang tags for translated pages
* Fix for Contact Form 7

= 2.8.35 =
* Admin notice added for conflicting plugins
* Disabled translation of non-selected languages when accessed directly in sub-directory URL structure mode
* Update to WordPress 4.9.1 before updating GTranslate
* Fixed update issue related to bug in new WP 4.9 flatten_dirlist function

= 2.8.34 =
* Non-stable: Fixed update issue related to bug in new WP 4.9 flatten_dirlist function. Important: If you are using Globe widget look, make sure to open GTranslate settings page, click "Reset Code to Default" under Widget Code section and Save.

= 2.8.33 =
* Fixed issue related to new version of Contact Form 7
* Ready for WordPress 4.9

= 2.8.32 =
* New feature: auto switch language based on browser language settigns
* Minor fixes: Greek name in native alphabet, Flag size option for Globe Widget look, vertical position in pixels

= 2.8.31 =
* Removed email and name from Intercom chat

= 2.8.30 =
* Fixed issue with double gzip compression when zlib.output_compression is on

= 2.8.29 =
* Lazy image loading added for popup and nice dropdown look
* Fixed languages list hiding issue on narrow screens
* Fixed popup widget look issue for mobile devices

= 2.8.28 =
* Changed static content paths to be relative to scheme
* Added "notranslate" class for dropdown widget look
* Added drodpown select wrapper id for easy CSS styling
* PHP URL rewriting added for some environments without .htaccess support: pantheon, flywheel, etc
* Fixed issue in url addon related to relative path location redirects

= 2.8.27 =
* Fixed issue for some mobile phones related to nice looking dropdown selector staying open
* Fixed issue related to Cloudflare 1000 error
* Fixed caching issue with modified translations

= 2.8.26 =
* Fixed relative path issue in .htaccess file for some websites which use mixed https and http
* Fixed IE javascript error on GTranslate Settings page preventing correct rendering of options
* Fixed popup view issue to show the selected language correctly
* Fixed issue when changing language from language with 3 letter language code to another
* A hint on re-ordering the languages list for better user experience was added
* Reset widget code to default button was added

= 2.8.25 =
* New widget look added - Popup
* Native template RTL support added

= 2.8.24 =
* No-scroll option added for floating language selector
* Now you can add more than one GTranslate widget to your sidebar

= 2.8.23 =
* Show native language names option turned off by default
* Fixed issue with initial rendering of the language selector
* Documentation updated

= 2.8.22 =
* Intercom live chat support integrated
* Gzip compression optimizations

= 2.8.21 =
* Fix for gzip compression issues on mobile phones

= 2.8.20 =
* Google neural machine translations, better quality!!!
* Added gzip compression for communication between server and client
* Fixed issue with double translation

= 2.8.19 =
* Render gtranslate selector in a submenu if the menu link has gtranslate-parent class
* Bug fixed when select tag has more than one class assigned

= 2.8.18 =
* Make sure default language is always selected
* Paid pricing updated
* Disable text highlighting when translated

= 2.8.17 =
* Fixed saving translation issue which appeared in 2.8.16 version
* Minor readme fixes

= 2.8.16 =
* Added option to save encoded HTML to avoid some firewall blocking
* Updated readme to look better with the new wp.org plugin updates
* Added link to easily navigate from widgets to plugin settings page

= 2.8.15 =
* Fix for saving issue on GoDaddy hosting
* Fix for double gziping in sub-directory URL structure when using Sucuri service

= 2.8.14 =
* Added Argentina and Colombia alternative flags
* Fixed bug in Nice looking dropdown look related to clicking the last dropdown element
* Fixed Quebec flag issue
* Fixed caching incompatability issue in nice looking dropdown look with GoDaddy cache, W3 Total Cache and WP Fastest Cache

= 2.8.13 =
* Fixed bug with Globe widget look
* Disables conflicting similar translation plugins
* Fixed bug appeared in the latest version with the number of available languages

= 2.8.12 =
* Tweaks to make it work better with WooCommerce
* Fixed bug when turning off native language names option
* Fixed bug with reordering languages
* Fixed bug with updating the plugin when using sub-directory option
* Fixed bug in doGTrnaslate javascript function
* Fixed bug with floating selector when admin bar is visible (thanks to @redoper)
* Readme updated to comply with Wordpress directory guidelines (keywords removed WPML, qtranslate, transposh, loco translate, polylang, prisna translate, gts translation, lingotek, google website translator, global translator)

= 2.8.11 =
* Fix for open redirect issue
* Fix for incorrect selected language in nice dropdown

= 2.8.10 =
* Added Quebec and Canada alternative flags for French and English

= 2.8.9 =
* Major changes
* Added missing flags, so all 104 languages have flags now
* New 48px size flags added
* New widget look added Flags and Language name
* New widget look added Flags and Language code
* New widget look added Language names
* New widget look added Language codes

= 2.8.8 =
* Fix for flags rendering issue in menu
* Fix for analytics code in onfly mode
* Fixed issue with some template conflicts

= 2.8.7 =
* Happy New Year! :)
* Fix for mystery language change when selecting default language
* .htaccess plugin_path now relative without http://example.com
* Bug fixed, scrolling for dropdown flags doesn't work on some templates

= 2.8.6 =
* Fixed bug on options page related to native language names
* Plugin keywords added: multilanguage, multilingual, language, bilingual, i18n
* Vimeo videos replaced by YouTube videos: GTranslate video and Translation Proxy video

= 2.8.5 =
* Show languages in their native names
* Automatically select default language based on wordpress locale
* Coding issue with PHP Strict Standards and Fatal Error on some PHP versions fixed
* Error messages more informative

= 2.8.4 =
* New option to select in which menu the selector should appear

= 2.8.3 =
* Added URL add-on to easily enable sub-directory URL structure (paid)
* New option to easily enable URL Translation
* Disallow both sub-domain and sub-directory URL structure selection at the same time
* Fix for language change issue when URL Translation is on

= 2.8.2 =
* Floating language selector option added: Top left, Top right, Bottom left, Bottom right

= 2.8.1 =
* New Globe widget look added
* Plugin localization added
* Language list reordering added

= 2.0.21 =
* New option to render in primary menu

= 2.0.20 =
* Fix for depreciated code: PLUGINDIR

= 2.0.19 =
* Added support message
* Added Live Chat on GTranslate options page
* Plugin tags added: polylang, prisna, gts, localize, lingotek, smartling
* Plugin tags added: qtranslate, loco translate, google website translator, translate wordpress
* Plugin tags added: translate, transposh, glabol translator, machine translate, wp translate

= 2.0.18 =
* Alternative flags added: USA flag, Brazil flag, Mexico flag

= 2.0.17 =
* GTranslate settings logo moved to localhost

= 2.0.16 =
* Fixed possible Cross-Site-Scripting security issue
* GTranslate logo moved to localhost
* Update notice removed

= 2.0.15 =
* Fix for not saving GTranslate configuration on some hostings
* Tested up to 4.6
* Plugin tags modified: language translator, weglot, scrybs, wpml

= 2.0.14 =
* Fix for javascript CDATA
* Support for Google new analytics.js added

= 2.0.13 =
* Notifications added

= 2.0.12 =
* Readme updated, demo videos added
* Fixed issue in Nice dropdown look

= 2.0.11 =
* Fixed issue with default language in Nice dropdown look

= 2.0.10 =
* Updated links, FAQ and readme

= 2.0.9 =
* Fixed undefined variable PHP notice

= 2.0.8 =
* Added 13 new languages: Amharic, Corsican, Frisian, Kyrgyz, Hawaiian, Kurdish (Kurmanji), Luxembourgish, Samoan, Scots Gaelic, Shona, Sindhi, Pashto and Xhosa

= 2.0.7 =
* PHP notice and warning messages fixed

= 2.0.6 =
* Updated option names to be clear

= 2.0.5 =
* New widget look has been added: Nice dropdown with flags
* Hiding and showing options in settings interface to be user friendly

= 2.0.4 =
* Added 34 new languages!
* Support for wordpress 4.4

= 2.0.3 =
* Update recommended message added - a minor change compared to 2.0.2

= 2.0.2 =
* Added support for sites using SSL

= 2.0.1 =
* Admin refreshed

= 1.0.38 =
* Fix for flags display with some templates

= 1.0.37 =
* Bug fixed with new versions of PHP
* Translation queue added

= 1.0.36 =
* On Fly IE9 bug fixed

= 1.0.35 =
* On Fly method is back

= 1.0.34 =
* Error fixed with Chinese language in Enterprise mode

= 1.0.33 =
* Support for Enterprise version added

= 1.0.30 =
* Link and call home updated

= 1.0.29 =
* Custom update checker added

= 1.0.28 =
* Links changed

= 1.0.27 =
* Changed text in noscript tag

= 1.0.26 =
* Fixed issue with SSL admin

= 1.0.25 =
* Fixed installation notification on update event
* Removed unnecessary commented code

= 1.0.24 =
* Tracking added for collecting statistics

= 1.0.23 =
* Bug fixed with javascript jquery loading option

= 1.0.22 =
* Bug fixed with language change in Pro mode
* Added noscript tag

= 1.0.21 =
* Statistics collector temporarily disabled

= 1.0.20 =
* Changed the statistics collector server from Google AppEngine to GoDaddy

= 1.0.19 =
* Added a dummy img to collect usage statistics

= 1.0.18 =
* Fixed issue with the parameters saving in the admin

= 1.0.17 =
* Minor changes in readme.txt

= 1.0.16 =
* Added [GTranslate] syntax to be used inside wordpress articles/pages

= 1.0.15 =
* Added aff link to track visits from wordpress on my site

= 1.0.14 =
* Added notes, so people will not copy the code into their posts

= 1.0.13 =
* jQuery conflicts fixed, using default wp jquery library
* jQuery Translate updated to v1.4.7
* CSRF Security Vulnerability fix

= 1.0.12 =
* No changes made

= 1.0.11 =
* Analytics feature implemented. If you have Google Analytics _gaq code on your site you can enable it and see the language usage.
* Fixed issue with the cookie path in On Fly method

= 1.0.10 =
* Bug fixed: configuration settings were lost after update
* FAQ updated
* Changelog reordered

= 1.0.9 =
* Updated the description

= 1.0.8 =
* Keywords added in the description page
* FAQ updated

= 1.0.7 =
* Widget title changed
* Link added

= 1.0.6 =
* Bug fixed: magic_quotes_gpc problem

= 1.0.5 =
* Bug fixed: settings save problem

= 1.0.4 =
* Minor changes

= 1.0.3 =
* Stable version released

= 1.0.2 =
* RC2 version

= 1.0.1 =
* RC1 version

= 1.0.0 =
* Initial version for WordPress

== Upgrade Notice ==
= 5.0.1 =
Replaces the legacy translation widget. Review service terms, test language selectors and custom CSS.